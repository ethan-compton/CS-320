
import java.util.HashMap;

public class ContactService {
    private final HashMap<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null || contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact ID already exists or contact is null");
        }
        contacts.put(contact.getContactID(), contact);
    }

    public void deleteContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.remove(contactID);
    }

    public void updateFirstName(String contactID, String firstName) {
        Contact contact = contacts.get(contactID);
        if (contact == null) throw new IllegalArgumentException("Contact ID not found");
        contact.setFirstName(firstName);
    }

    public void updateLastName(String contactID, String lastName) {
        Contact contact = contacts.get(contactID);
        if (contact == null) throw new IllegalArgumentException("Contact ID not found");
        contact.setLastName(lastName);
    }

    public void updatePhone(String contactID, String phone) {
        Contact contact = contacts.get(contactID);
        if (contact == null) throw new IllegalArgumentException("Contact ID not found");
        contact.setPhone(phone);
    }

    public void updateAddress(String contactID, String address) {
        Contact contact = contacts.get(contactID);
        if (contact == null) throw new IllegalArgumentException("Contact ID not found");
        contact.setAddress(address);
    }

    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}
