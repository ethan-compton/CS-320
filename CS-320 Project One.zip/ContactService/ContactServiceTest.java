
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("001", "Alice", "Smith", "1234567890", "456 Elm St");
        service.addContact(contact);
        assertEquals("Alice", service.getContact("001").getFirstName());
    }

    @Test
    public void testAddDuplicateContact() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("001", "Alice", "Smith", "1234567890", "456 Elm St");
        Contact contact2 = new Contact("001", "Bob", "Jones", "0987654321", "789 Oak St");
        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("001", "Alice", "Smith", "1234567890", "456 Elm St");
        service.addContact(contact);
        service.deleteContact("001");
        assertNull(service.getContact("001"));
    }

    @Test
    public void testUpdateFields() {
        ContactService service = new ContactService();
        Contact contact = new Contact("001", "Alice", "Smith", "1234567890", "456 Elm St");
        service.addContact(contact);
        service.updateFirstName("001", "Alicia");
        service.updateLastName("001", "Johnson");
        service.updatePhone("001", "0987654321");
        service.updateAddress("001", "999 Pine St");
        assertEquals("Alicia", service.getContact("001").getFirstName());
        assertEquals("Johnson", service.getContact("001").getLastName());
        assertEquals("0987654321", service.getContact("001").getPhone());
        assertEquals("999 Pine St", service.getContact("001").getAddress());
    }
}
