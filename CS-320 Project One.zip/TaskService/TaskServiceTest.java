import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("1", "Test", "Testing add");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("1"));
    }

    @Test
    public void testAddDuplicateTaskId() {
        Task task1 = new Task("1", "Test1", "First");
        Task task2 = new Task("1", "Test2", "Second");
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("2", "ToDelete", "Delete this");
        taskService.addTask(task);
        taskService.deleteTask("2");
        assertNull(taskService.getTask("2"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("3", "OldName", "Desc");
        taskService.addTask(task);
        taskService.updateTaskName("3", "NewName");
        assertEquals("NewName", taskService.getTask("3").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("4", "Name", "OldDesc");
        taskService.addTask(task);
        taskService.updateTaskDescription("4", "NewDesc");
        assertEquals("NewDesc", taskService.getTask("4").getDescription());
    }

    @Test
    public void testDeleteNonexistentTask() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("999"));
    }
}
