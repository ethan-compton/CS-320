import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("123", "TaskName", "This is a description.");
        assertEquals("123", task.getTaskId());
        assertEquals("TaskName", task.getName());
        assertEquals("This is a description.", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Desc");
        });
    }

    @Test
    public void testNullName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", null, "Desc");
        });
    }

    @Test
    public void testLongName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "ThisIsAVeryLongTaskNameThatExceedsLimit", "Desc");
        });
    }

    @Test
    public void testSetNameTooLong() {
        Task task = new Task("123", "Task", "Desc");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("ThisIsAVeryLongTaskNameThatExceedsLimit");
        });
    }

    @Test
    public void testSetDescriptionTooLong() {
        Task task = new Task("123", "Task", "Desc");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("This is a very long description that definitely exceeds the character limit of fifty characters.");
        });
    }
}
