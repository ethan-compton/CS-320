import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment appointment = new Appointment("1234567890", futureDate, "Dentist appointment");

        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Dentist appointment", appointment.getDescription());
    }

    @Test
    public void testInvalidId() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Checkup");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Checkup");
        });
    }

    @Test
    public void testInvalidDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Past appointment");
        });
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, null);
        });

        String longDesc = "This description is way too long for the allowed fifty character limit!";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, longDesc);
        });
    }
}