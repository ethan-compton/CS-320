import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    public void testAddAndDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment appointment = new Appointment("abc123", futureDate, "Vet visit");

        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("abc123"));

        service.deleteAppointment("abc123");
        assertNull(service.getAppointment("abc123"));
    }

    @Test
    public void testAddDuplicateId() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment appointment1 = new Appointment("id001", futureDate, "First");
        Appointment appointment2 = new Appointment("id001", futureDate, "Second");

        service.addAppointment(appointment1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    public void testDeleteInvalidId() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("nonexistent");
        });
    }
}